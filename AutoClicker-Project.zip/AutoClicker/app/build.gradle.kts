plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.myclicker.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myclicker.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    // স্থায়ী কী: প্রতিবার একই সাইন হয়, তাই নতুন ভার্সন আগের অ্যাপের ওপর আপডেট হিসেবে বসে
    signingConfigs {
        create("main") {
            storeFile = file("release.jks")
            storePassword = "autoclicker123"
            keyAlias = "autoclicker"
            keyPassword = "autoclicker123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("main")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("main")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
