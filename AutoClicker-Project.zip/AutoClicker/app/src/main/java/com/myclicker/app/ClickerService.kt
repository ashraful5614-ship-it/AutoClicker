package com.myclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Accessibility Service: স্ক্রিনে tap/swipe করে + ভাসমান কন্ট্রোল প্যানেল দেখায়।
 * TYPE_ACCESSIBILITY_OVERLAY ব্যবহার হয়, তাই আলাদা "draw over other apps" পারমিশন লাগে না।
 */
class ClickerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickerService? = null
    }

    private class Marker(
        val view: MarkerView,
        val lp: WindowManager.LayoutParams,
        val index: Int,
        val isEnd: Boolean
    )

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private val points = mutableListOf<ClickPoint>()
    private val markers = mutableListOf<Marker>()
    private var multi = true

    var panelShown = false
        private set
    private var running = false
    private var markersVisible = true
    private var collapsed = false
    private var idx = 0
    private var loopsDone = 0

    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var playIcon: IconView? = null
    private var chevron: IconView? = null
    private val collapsibles = mutableListOf<View>()
    private var settingsCard: View? = null
    private var lineView: LineView? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopRun()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hidePanel()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hidePanel()
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int) = UI.dp(this, v)

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun overlayLp(w: Int, h: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun defaultTap(i: Int) = ClickPoint(
        screenW() / 2,
        (screenH() / 3 + (i % 6) * dp(64)).coerceAtMost(screenH() - dp(120))
    )

    private fun defaultSwipe(i: Int): ClickPoint {
        val y = (screenH() / 2 + (i % 4) * dp(64)).coerceAtMost(screenH() - dp(120))
        return ClickPoint(screenW() / 3, y, true, screenW() * 2 / 3, y)
    }

    // ---------------------------------------------------------------- panel show / hide

    fun showPanel(multiMode: Boolean, autoStart: Boolean = false) {
        if (!::wm.isInitialized) return
        if (panelShown) hidePanel()
        multi = multiMode
        points.clear()
        Prefs.pending?.let { pend -> points.addAll(pend.map { it.copy() }) }
        Prefs.pending = null
        if (!multi) {
            while (points.size > 1) points.removeAt(points.size - 1)
            if (points.isNotEmpty() && points[0].isSwipe) points[0].isSwipe = false
        }
        if (points.isEmpty()) points.add(defaultTap(0))

        markersVisible = true
        collapsed = false
        val lv = LineView(this)
        lineView = lv
        wm.addView(lv, overlayLp(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT, false
        ))
        buildMarkers()
        buildPanel()
        panelShown = true
        // সেভ করা স্ক্রিপ্ট Play করলে নিজে থেকেই চালু হবে (অ্যাপ ব্যাকগ্রাউন্ডে যাওয়ার সময় দিয়ে)
        if (autoStart) startRun(1500L)
    }

    /** অ্যাপ থেকে স্ক্রিপ্ট লোড করলে প্যানেল চালু থাকা অবস্থায় রিফ্রেশ */
    fun reload(multiMode: Boolean) {
        showPanel(multiMode)
    }

    fun hidePanel() {
        if (!::wm.isInitialized) return
        stopRun()
        hideHud()
        closeSettings()
        for (m in markers) runCatching { wm.removeView(m.view) }
        markers.clear()
        lineView?.let { v -> runCatching { wm.removeView(v) } }
        lineView = null
        panel?.let { v -> runCatching { wm.removeView(v) } }
        panel = null
        panelLp = null
        collapsibles.clear()
        points.clear()   // সেভ না করা সব কিছু মুছে যায়
        panelShown = false
    }

    // ---------------------------------------------------------------- markers

    private fun buildMarkers() {
        for (m in markers) runCatching { wm.removeView(m.view) }
        markers.clear()
        val size = dp(46)
        points.forEachIndexed { i, p ->
            addMarker(i, false, p.x, p.y, size)
            if (p.isSwipe) addMarker(i, true, p.x2, p.y2, size)
        }
        lineView?.invalidate()
        applyVisibility()
        bringPanelFront()
    }

    private fun addMarker(i: Int, isEnd: Boolean, cx: Int, cy: Int, size: Int) {
        val v = MarkerView(this, (i + 1).toString(), isEnd)
        val lp = overlayLp(size, size, !running)
        lp.x = cx - size / 2
        lp.y = cy - size / 2
        val m = Marker(v, lp, i, isEnd)
        attachDrag(m)
        wm.addView(v, lp)
        markers.add(m)
    }

    private fun attachDrag(m: Marker) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        m.view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = m.lp.x
                    oy = m.lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    m.lp.x = ox + (e.rawX - sx).toInt()
                    m.lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(m.view, m.lp)
                    val cx = m.lp.x + m.lp.width / 2
                    val cy = m.lp.y + m.lp.height / 2
                    val p = points.getOrNull(m.index)
                    if (p != null) {
                        if (m.isEnd) {
                            p.x2 = cx
                            p.y2 = cy
                        } else {
                            p.x = cx
                            p.y = cy
                        }
                    }
                    lineView?.invalidate()
                }
            }
            true
        }
    }

    private fun setMarkersTouchable(touchable: Boolean) {
        for (m in markers) {
            m.lp.flags = if (touchable) {
                m.lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                m.lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            runCatching { wm.updateViewLayout(m.view, m.lp) }
        }
    }

    private fun applyVisibility() {
        val vis = if (markersVisible) View.VISIBLE else View.INVISIBLE
        for (m in markers) m.view.visibility = vis
        lineView?.visibility = vis
    }

    // ---------------------------------------------------------------- floating panel

    private fun buildPanel() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(4), dp(2), dp(4), dp(4))
        col.background = UI.rounded(Color.parseColor("#F0262B3D"), 22, this)

        // টেনে সরানোর হ্যান্ডেল
        val handle = View(this)
        handle.background = UI.rounded(Color.parseColor("#6B7390"), 3, this)
        val hWrap = LinearLayout(this)
        hWrap.gravity = Gravity.CENTER
        hWrap.addView(handle, LinearLayout.LayoutParams(dp(26), dp(5)))
        col.addView(hWrap, LinearLayout.LayoutParams(dp(46), dp(22)))

        val lp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
        lp.x = screenW() - dp(62)
        lp.y = screenH() / 4

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        hWrap.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    panel?.let { runCatching { wm.updateViewLayout(it, lp) } }
                }
            }
            true
        }

        fun btn(type: Int, collapsible: Boolean, onClick: () -> Unit): IconView {
            val iv = IconView(this, type)
            iv.setOnClickListener { onClick() }
            col.addView(iv, LinearLayout.LayoutParams(dp(46), dp(46)))
            if (collapsible) collapsibles.add(iv)
            return iv
        }

        playIcon = btn(IconView.PLAY, false) { if (running) stopRun() else startRun() }
        playIcon?.tint = UI.GREEN
        btn(IconView.TARGET, true) { addPoint(false) }
        btn(IconView.SWIPE, true) { addPoint(true) }
        btn(IconView.MINUS, true) { removeLast() }
        btn(IconView.SAVE, true) { saveScript() }
        btn(IconView.GEAR, true) { toggleSettings() }
        btn(IconView.EYE, true) {
            markersVisible = !markersVisible
            applyVisibility()
        }
        btn(IconView.CLOSE, true) {
            hidePanel()
        }
        chevron = btn(IconView.UP, false) {
            collapsed = !collapsed
            for (v in collapsibles) v.visibility = if (collapsed) View.GONE else View.VISIBLE
            chevron?.type = if (collapsed) IconView.DOWN else IconView.UP
            chevron?.invalidate()
        }

        panel = col
        panelLp = lp
        wm.addView(col, lp)
    }

    private fun bringPanelFront() {
        handler.post {
            val p = panel
            val lp = panelLp
            if (p != null && lp != null && panelShown) {
                runCatching {
                    wm.removeViewImmediate(p)
                    wm.addView(p, lp)
                }
            }
        }
    }

    // ---------------------------------------------------------------- actions

    private fun editable(): Boolean {
        if (running) {
            toast("Stop first")
            return false
        }
        return true
    }

    private fun addPoint(swipe: Boolean) {
        if (!editable()) return
        if (!multi) {
            toast("1-Point mode: only one point")
            return
        }
        if (points.size >= 30) {
            toast("Maximum 30 points")
            return
        }
        points.add(if (swipe) defaultSwipe(points.size) else defaultTap(points.size))
        buildMarkers()
    }

    private fun removeLast() {
        if (!editable()) return
        if (points.isEmpty()) return
        points.removeAt(points.size - 1)
        buildMarkers()
    }

    private fun saveScript() {
        if (points.isEmpty()) {
            toast("Nothing to save")
            return
        }
        val list = Prefs.scripts(this)
        val name = "Script " + SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date())
        list.add(
            Script(
                name, multi,
                Field.INTERVAL.get(this), Field.LOOPS.get(this),
                points.map { it.copy() },
                Field.SWIPE.get(this), Field.HOLD.get(this)
            )
        )
        Prefs.saveScripts(this, list)
        toast("Saved to Scripts")
    }

    private fun toggleSettings() {
        if (settingsCard != null) {
            closeSettings()
            return
        }
        if (!editable()) return
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(8), dp(14), dp(8), dp(14))
        card.background = UI.rounded(Color.parseColor("#F5222637"), 20, this)

        val title = UI.text(this, "Settings", 18f, UI.TEXT, true)
        title.setPadding(dp(12), 0, dp(12), dp(6))
        card.addView(title)
        for (f in Field.values()) card.addView(UI.stepperRow(this, f))

        val done = UI.text(this, "Done", 15f, UI.TEXT, true)
        done.gravity = Gravity.CENTER
        done.background = UI.rounded(UI.ACCENT, 12, this)
        done.setOnClickListener { closeSettings() }
        val dlp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(44)
        )
        dlp.setMargins(dp(12), dp(10), dp(12), 0)
        card.addView(done, dlp)

        val lp = overlayLp(minOf(dp(340), screenW() - dp(24)), WindowManager.LayoutParams.WRAP_CONTENT, true)
        lp.gravity = Gravity.CENTER
        settingsCard = card
        wm.addView(card, lp)
    }

    private fun closeSettings() {
        settingsCard?.let { v -> runCatching { wm.removeView(v) } }
        settingsCard = null
    }

    // ---------------------------------------------------------------- click engine

    private val stepRunnable = Runnable { performCurrent() }

    private var hud: TextView? = null
    private var runStart = 0L
    private val hudTick = object : Runnable {
        override fun run() {
            updateHud()
            handler.postDelayed(this, 500)
        }
    }

    private fun showHud() {
        if (hud != null) return
        val t = TextView(this)
        t.textSize = 13f
        t.setTextColor(Color.WHITE)
        t.setPadding(dp(14), dp(6), dp(14), dp(6))
        t.background = UI.rounded(Color.parseColor("#CC000000"), 16, this)
        val lp = overlayLp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, false
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = dp(36)
        hud = t
        runStart = SystemClock.elapsedRealtime()
        wm.addView(t, lp)
        updateHud()
        handler.postDelayed(hudTick, 500)
    }

    private fun updateHud() {
        val t = hud ?: return
        val sec = (SystemClock.elapsedRealtime() - runStart) / 1000
        val loops = Field.LOOPS.get(this)
        val total = if (loops == 0) "∞" else loops.toString()
        t.text = "%02d:%02d:%02d   Loop %d/%s".format(sec / 3600, (sec / 60) % 60, sec % 60, loopsDone, total)
    }

    private fun hideHud() {
        handler.removeCallbacks(hudTick)
        hud?.let { v -> runCatching { wm.removeView(v) } }
        hud = null
    }

    fun startRun(initialDelay: Long = 400L) {
        if (points.isEmpty()) {
            toast("Add a point first")
            return
        }
        closeSettings()
        running = true
        idx = 0
        loopsDone = 0
        setMarkersTouchable(false)
        playIcon?.type = IconView.PAUSE
        playIcon?.invalidate()
        showHud()
        handler.postDelayed(stepRunnable, initialDelay)
    }

    private fun stopRun() {
        if (!running && playIcon?.type != IconView.PAUSE) return
        running = false
        hideHud()
        handler.removeCallbacks(stepRunnable)
        if (panelShown) setMarkersTouchable(true)
        playIcon?.type = IconView.PLAY
        playIcon?.invalidate()
    }

    private fun jit(v: Int, j: Int): Float {
        val r = if (j > 0) Random.nextInt(-j, j + 1) else 0
        return (v + r).coerceAtLeast(0).toFloat()
    }

    private fun performCurrent() {
        if (!running) return
        if (idx >= points.size) idx = 0
        val p = points[idx]
        val j = Field.JITTER.get(this)

        val path = Path()
        path.moveTo(jit(p.x, j), jit(p.y, j))
        if (p.isSwipe) path.lineTo(jit(p.x2, j), jit(p.y2, j))
        val dur = if (p.isSwipe) Field.SWIPE.get(this).toLong() else Field.HOLD.get(this).toLong()

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()

        val cb = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                next()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                next()
            }
        }
        val ok = dispatchGesture(gesture, cb, null)
        if (!ok) next()
    }

    private fun next() {
        if (!running) return
        idx++
        if (idx >= points.size) {
            idx = 0
            loopsDone++
            val loops = Field.LOOPS.get(this)
            if (loops > 0 && loopsDone >= loops) {
                stopRun()
                toast("Finished")
                return
            }
        }
        handler.postDelayed(stepRunnable, Field.INTERVAL.get(this).toLong())
    }

    // ---------------------------------------------------------------- swipe lines

    private inner class LineView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#552ECC71")
            strokeWidth = dp(26).toFloat()
            strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(c: Canvas) {
            for (pt in points) {
                if (pt.isSwipe) {
                    c.drawLine(pt.x.toFloat(), pt.y.toFloat(), pt.x2.toFloat(), pt.y2.toFloat(), paint)
                }
            }
        }
    }
}
