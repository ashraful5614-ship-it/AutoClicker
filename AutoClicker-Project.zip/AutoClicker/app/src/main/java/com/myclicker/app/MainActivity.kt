package com.myclicker.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val navIcons = mutableListOf<IconView>()
    private val navLabels = mutableListOf<TextView>()
    private var tab = 0

    private fun dp(v: Int) = UI.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = UI.BG
        window.navigationBarColor = UI.NAV
        Prefs.clearLegacy(this)
        buildUi()
        showTab(0)
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) showTab(tab)
    }

    // ------------------------------------------------------------------ frame

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(UI.BG)
        root.fitsSystemWindows = true

        // header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(20), dp(16), dp(20), dp(8))

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = UI.text(this, "AUTO CLICKER", 24f, UI.TEXT, true)
        title.letterSpacing = 0.05f
        titles.addView(title)
        titles.addView(UI.text(this, "Automatic Tap & Gesture", 12f, UI.MUTED))
        header.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val badge = UI.text(this, "AD-FREE", 11f, UI.GREEN, true)
        badge.setPadding(dp(10), dp(5), dp(10), dp(5))
        badge.background = UI.rounded(Color.parseColor("#1F2ECC71"), 14, this)
        header.addView(badge)
        root.addView(header)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // bottom nav
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(UI.NAV)
        val names = listOf("Clicker", "Scripts", "Settings")
        val types = listOf(IconView.TARGET, IconView.LIST, IconView.GEAR)
        for (i in 0..2) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            val ic = IconView(this, types[i])
            val lb = UI.text(this, names[i], 11f, UI.MUTED)
            lb.gravity = Gravity.CENTER
            item.addView(ic, LinearLayout.LayoutParams(dp(30), dp(30)))
            item.addView(lb)
            item.setOnClickListener { showTab(i) }
            navIcons.add(ic)
            navLabels.add(lb)
            nav.addView(item, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(nav)

        setContentView(root)
    }

    private fun showTab(i: Int) {
        tab = i
        for (k in 0..2) {
            val c = if (k == i) UI.ACCENT else UI.MUTED
            navIcons[k].tint = c
            navLabels[k].setTextColor(c)
        }
        content.removeAllViews()
        val page = when (i) {
            0 -> clickerPage()
            1 -> scriptsPage()
            else -> settingsPage()
        }
        content.addView(page)
    }

    // ------------------------------------------------------------------ helpers

    private fun serviceEnabled(): Boolean = ClickerService.instance != null

    private fun askEnableAccessibility() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Enable Accessibility")
            .setMessage(
                "To tap on the screen, turn on \"Auto Clicker\" in Accessibility settings " +
                        "(Installed / Downloaded apps).\n\n" +
                        "Android 13+: if the switch is greyed out, open App info for this app, " +
                        "tap ⋮ (top right) and choose \"Allow restricted settings\", then try again."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton("App info") { _, _ ->
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = android.net.Uri.parse("package:$packageName")
                startActivity(i)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun scroll(inner: View): View {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(inner)
        return sv
    }

    private fun primaryButton(label: String, color: Int, onClick: () -> Unit): TextView {
        val b = UI.text(this, label, 17f, UI.TEXT, true)
        b.gravity = Gravity.CENTER
        b.letterSpacing = 0.05f
        b.background = UI.rounded(color, 12, this)
        b.setOnClickListener { onClick() }
        return b
    }

    // ------------------------------------------------------------------ Clicker tab

    private fun clickerPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(8), dp(18), dp(16))

        page.addView(UI.text(this, "Select Mode", 20f, UI.TEXT, true))

        val multi = Prefs.isMulti(this)

        val cardsHolder = LinearLayout(this)
        cardsHolder.orientation = LinearLayout.VERTICAL
        page.addView(cardsHolder)

        fun modeCard(
            type: Int, title: String, desc: String, selected: Boolean, onClick: () -> Unit
        ): View {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.HORIZONTAL
            card.gravity = Gravity.CENTER_VERTICAL
            card.setPadding(dp(16), dp(18), dp(16), dp(18))
            card.background = UI.rounded(if (selected) UI.ACCENT else UI.CARD, 18, this)

            val ic = IconView(this, type)
            ic.tint = if (selected) Color.WHITE else UI.MUTED
            card.addView(ic, LinearLayout.LayoutParams(dp(58), dp(58)))

            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(14), 0, 0, 0)
            col.addView(UI.text(this, title, 20f, if (selected) UI.TEXT else Color.parseColor("#B5BAD0"), true))
            col.addView(UI.text(this, desc, 13f, if (selected) Color.parseColor("#E3EBFF") else UI.MUTED))
            card.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            card.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            card.layoutParams = lp
            return card
        }

        cardsHolder.addView(
            modeCard(
                IconView.TARGET, "1-Point Mode",
                "Tap a single position repeatedly at specified intervals", !multi
            ) {
                Prefs.setMulti(this, false)
                showTab(0)
            }
        )
        cardsHolder.addView(
            modeCard(
                IconView.MULTI, "Multi-Point Mode",
                "Set a series of taps/swipes in different positions", multi
            ) {
                Prefs.setMulti(this, true)
                showTab(0)
            }
        )

        // How to use
        val how = UI.text(this, "?  How to Use", 14f, UI.TEXT, true)
        how.gravity = Gravity.CENTER
        how.setPadding(dp(18), dp(10), dp(18), dp(10))
        how.background = UI.rounded(UI.CARD, 20, this)
        how.setOnClickListener {
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("How to Use")
                .setMessage(
                    "1. Pick a mode and press START.\n" +
                            "2. A floating bar appears over any app. Drag its top handle to move it.\n" +
                            "3. Tap the target icon to add a tap point, the arrow icon to add a swipe " +
                            "(Multi-Point only). Drag the numbered circles to the exact spots.\n" +
                            "4. Gear icon: interval, repeat count, tap duration, random offset.\n" +
                            "5. Play starts / pauses the clicking. Floppy icon saves the setup to Scripts. " +
                            "Eye hides the markers. ✕ closes the bar."
                )
                .setPositiveButton("Got it", null)
                .show()
        }
        val hlp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.topMargin = dp(22)
        page.addView(how, hlp)

        // spacer
        page.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))

        // accessibility status
        val ok = serviceEnabled()
        val status = UI.text(
            this,
            if (ok) "●  Accessibility service is ON" else "●  Accessibility service is OFF – tap to enable",
            13f, if (ok) UI.GREEN else Color.parseColor("#FF6B6B")
        )
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(18), 0, dp(10))
        status.setOnClickListener { if (!serviceEnabled()) askEnableAccessibility() }
        page.addView(status, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        // START / STOP
        val svc = ClickerService.instance
        val shown = svc != null && svc.panelShown
        val btn = primaryButton(if (shown) "STOP" else "START", if (shown) UI.DISABLED else UI.ACCENT) {
            val s = ClickerService.instance
            if (s == null) {
                askEnableAccessibility()
            } else if (s.panelShown) {
                s.hidePanel()
                showTab(0)
            } else {
                s.showPanel(Prefs.isMulti(this))
                moveTaskToBack(true)
            }
        }
        page.addView(btn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ))

        return page
    }

    // ------------------------------------------------------------------ Scripts tab

    private fun scriptsPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(8), dp(18), dp(16))
        page.addView(UI.text(this, "Saved Scripts", 20f, UI.TEXT, true))

        val list = Prefs.scripts(this)
        if (list.isEmpty()) {
            val empty = UI.text(
                this,
                "No saved scripts yet.\n\nPress START, set up your points, then tap the floppy-disk icon on the floating bar to save.",
                14f, UI.MUTED
            )
            empty.setPadding(0, dp(24), 0, 0)
            page.addView(empty)
            return scroll(page)
        }

        list.forEachIndexed { i, sc ->
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(16), dp(14), dp(16), dp(14))
            card.background = UI.rounded(UI.CARD, 16, this)

            card.addView(UI.text(this, sc.name, 17f, UI.TEXT, true))
            val mode = if (sc.multi) "Multi-Point" else "1-Point"
            val intervalTxt = Field.INTERVAL.format(sc.interval)
            val loopsTxt = Field.LOOPS.format(sc.loops)
            card.addView(
                UI.text(
                    this,
                    "$mode · ${sc.points.size} point(s) · every $intervalTxt · repeat $loopsTxt",
                    12f, UI.MUTED
                )
            )

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, dp(12), 0, 0)

            val run = UI.text(this, "▶ Play", 14f, UI.TEXT, true)
            run.gravity = Gravity.CENTER
            run.background = UI.rounded(UI.ACCENT, 10, this)
            run.setOnClickListener { runScript(sc, true) }

            val edit = UI.text(this, "Edit", 14f, UI.TEXT, true)
            edit.gravity = Gravity.CENTER
            edit.background = UI.rounded(UI.CARD2, 10, this)
            edit.setOnClickListener { runScript(sc, false) }

            val del = UI.text(this, "Delete", 14f, UI.TEXT, true)
            del.gravity = Gravity.CENTER
            del.background = UI.rounded(UI.DISABLED, 10, this)
            del.setOnClickListener {
                val all = Prefs.scripts(this)
                if (i < all.size) {
                    all.removeAt(i)
                    Prefs.saveScripts(this, all)
                }
                showTab(1)
            }

            val l1 = LinearLayout.LayoutParams(0, dp(40), 1f)
            l1.rightMargin = dp(8)
            row.addView(run, l1)
            val l2 = LinearLayout.LayoutParams(0, dp(40), 1f)
            l2.rightMargin = dp(8)
            row.addView(edit, l2)
            row.addView(del, LinearLayout.LayoutParams(0, dp(40), 1f))
            card.addView(row)

            val clp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            clp.topMargin = dp(12)
            page.addView(card, clp)
        }
        return scroll(page)
    }

    private fun runScript(sc: Script, autoStart: Boolean) {
        val svc = ClickerService.instance
        if (svc == null) {
            askEnableAccessibility()
            return
        }
        Prefs.setMulti(this, sc.multi)
        Prefs.pending = sc.points.map { it.copy() }
        Field.INTERVAL.set(this, sc.interval)
        Field.LOOPS.set(this, sc.loops)
        Field.SWIPE.set(this, sc.swipe)
        Field.HOLD.set(this, sc.hold)
        svc.showPanel(sc.multi, autoStart)
        moveTaskToBack(true)
    }

    // ------------------------------------------------------------------ Settings tab

    private fun settingsPage(): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(8), dp(18), dp(16))
        page.addView(UI.text(this, "Settings", 20f, UI.TEXT, true))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(4), dp(8), dp(4), dp(8))
        card.background = UI.rounded(UI.CARD, 16, this)
        for (f in Field.values()) card.addView(UI.stepperRow(this, f))
        val clp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        clp.topMargin = dp(14)
        page.addView(card, clp)

        val acc = LinearLayout(this)
        acc.orientation = LinearLayout.VERTICAL
        acc.setPadding(dp(16), dp(14), dp(16), dp(14))
        acc.background = UI.rounded(UI.CARD, 16, this)
        acc.addView(UI.text(this, "Accessibility service", 16f, UI.TEXT, true))
        val ok = serviceEnabled()
        acc.addView(
            UI.text(
                this,
                if (ok) "Enabled – ready to click." else "Disabled – required to perform taps and swipes.",
                13f, if (ok) UI.GREEN else Color.parseColor("#FF6B6B")
            )
        )
        val open = UI.text(this, "Open Accessibility Settings", 14f, UI.TEXT, true)
        open.gravity = Gravity.CENTER
        open.background = UI.rounded(UI.ACCENT, 10, this)
        open.setOnClickListener { askEnableAccessibility() }
        val olp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(42)
        )
        olp.topMargin = dp(12)
        acc.addView(open, olp)
        val alp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        alp.topMargin = dp(14)
        page.addView(acc, alp)

        val about = UI.text(
            this,
            "100% ad-free. No internet permission, no data collected. " +
                    "Everything stays on your phone.",
            12f, UI.MUTED
        )
        about.setPadding(dp(4), dp(18), dp(4), 0)
        page.addView(about)

        return scroll(page)
    }
}
