package com.myclicker.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** ফন্টের উপর নির্ভর না করে নিজেই আইকন আঁকে */
class IconView(ctx: Context, var type: Int) : View(ctx) {

    companion object {
        const val PLAY = 0
        const val PAUSE = 1
        const val ADD = 2
        const val SWIPE = 3
        const val MINUS = 4
        const val SAVE = 5
        const val GEAR = 6
        const val EYE = 7
        const val CLOSE = 8
        const val UP = 9
        const val DOWN = 10
        const val TARGET = 11
        const val MULTI = 12
        const val LIST = 13
    }

    var tint: Int = Color.WHITE
        set(v) {
            field = v
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun stroke(w: Float) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = tint
    }

    private fun fill() {
        p.style = Paint.Style.FILL
        p.color = tint
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = min(w, h)
        val cx = w / 2
        val cy = h / 2
        val s = m * 0.24f
        val sw = m * 0.075f

        when (type) {
            PLAY -> {
                fill()
                val path = Path()
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx + s * 1.1f, cy)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.close()
                c.drawPath(path, p)
            }
            PAUSE -> {
                fill()
                c.drawRoundRect(RectF(cx - s * 0.9f, cy - s, cx - s * 0.2f, cy + s), 4f, 4f, p)
                c.drawRoundRect(RectF(cx + s * 0.2f, cy - s, cx + s * 0.9f, cy + s), 4f, 4f, p)
            }
            ADD -> {
                stroke(sw)
                c.drawLine(cx - s, cy, cx + s, cy, p)
                c.drawLine(cx, cy - s, cx, cy + s, p)
            }
            MINUS -> {
                stroke(sw)
                c.drawLine(cx - s, cy, cx + s, cy, p)
            }
            SWIPE -> {
                stroke(sw)
                c.drawLine(cx - s * 1.2f, cy, cx + s * 1.2f, cy, p)
                c.drawLine(cx + s * 0.4f, cy - s * 0.8f, cx + s * 1.2f, cy, p)
                c.drawLine(cx + s * 0.4f, cy + s * 0.8f, cx + s * 1.2f, cy, p)
            }
            SAVE -> {
                stroke(sw)
                c.drawRoundRect(RectF(cx - s, cy - s, cx + s, cy + s), s * 0.35f, s * 0.35f, p)
                c.drawRect(RectF(cx - s * 0.5f, cy - s, cx + s * 0.4f, cy - s * 0.3f), p)
                c.drawRect(RectF(cx - s * 0.55f, cy + s * 0.2f, cx + s * 0.55f, cy + s), p)
            }
            GEAR -> {
                stroke(sw)
                c.drawCircle(cx, cy, s * 0.42f, p)
                c.drawCircle(cx, cy, s * 0.82f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val x1 = cx + (s * 0.82f * cos(a)).toFloat()
                    val y1 = cy + (s * 0.82f * sin(a)).toFloat()
                    val x2 = cx + (s * 1.2f * cos(a)).toFloat()
                    val y2 = cy + (s * 1.2f * sin(a)).toFloat()
                    c.drawLine(x1, y1, x2, y2, p)
                }
            }
            EYE -> {
                stroke(sw)
                c.drawOval(RectF(cx - s * 1.25f, cy - s * 0.7f, cx + s * 1.25f, cy + s * 0.7f), p)
                c.drawCircle(cx, cy, s * 0.35f, p)
            }
            CLOSE -> {
                stroke(sw)
                c.drawLine(cx - s * 0.8f, cy - s * 0.8f, cx + s * 0.8f, cy + s * 0.8f, p)
                c.drawLine(cx - s * 0.8f, cy + s * 0.8f, cx + s * 0.8f, cy - s * 0.8f, p)
            }
            UP -> {
                stroke(sw)
                c.drawLine(cx - s, cy + s * 0.4f, cx, cy - s * 0.5f, p)
                c.drawLine(cx, cy - s * 0.5f, cx + s, cy + s * 0.4f, p)
            }
            DOWN -> {
                stroke(sw)
                c.drawLine(cx - s, cy - s * 0.4f, cx, cy + s * 0.5f, p)
                c.drawLine(cx, cy + s * 0.5f, cx + s, cy - s * 0.4f, p)
            }
            TARGET -> {
                stroke(sw)
                c.drawCircle(cx, cy, s * 1.2f, p)
                c.drawCircle(cx, cy, s * 0.65f, p)
                fill()
                c.drawCircle(cx, cy, s * 0.22f, p)
            }
            MULTI -> {
                val r = m * 0.09f
                val ax = cx - m * 0.28f
                val ay = cy + m * 0.16f
                val bx = cx
                val by = cy - m * 0.18f
                val dx = cx + m * 0.28f
                val dy = cy + m * 0.08f
                stroke(sw * 0.6f)
                p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f, 8f), 0f)
                c.drawLine(ax, ay, bx, by, p)
                c.drawLine(bx, by, dx, dy, p)
                p.pathEffect = null
                fill()
                c.drawCircle(ax, ay, r, p)
                c.drawCircle(bx, by, r, p)
                c.drawCircle(dx, dy, r, p)
            }
            LIST -> {
                stroke(sw)
                for (i in -1..1) {
                    val y = cy + i * s * 0.8f
                    c.drawLine(cx - s * 0.2f, y, cx + s, y, p)
                    fill()
                    c.drawCircle(cx - s * 0.85f, y, sw * 0.7f, p)
                    stroke(sw)
                }
            }
        }
    }
}

/** স্ক্রিনে ভাসমান নম্বর-দেওয়া পয়েন্ট মার্কার */
class MarkerView(ctx: Context, private val label: String, private val isEnd: Boolean) : View(ctx) {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        val base = if (isEnd) Color.parseColor("#F5A623") else Color.parseColor("#2ECC71")
        fillP.style = Paint.Style.FILL
        fillP.color = (base and 0x00FFFFFF) or 0x88000000.toInt()
        strokeP.style = Paint.Style.STROKE
        strokeP.color = base
        textP.color = Color.WHITE
        textP.textAlign = Paint.Align.CENTER
        textP.isFakeBoldText = true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = min(w, h) / 2f
        strokeP.strokeWidth = r * 0.12f
        c.drawCircle(w / 2, h / 2, r - strokeP.strokeWidth, fillP)
        c.drawCircle(w / 2, h / 2, r - strokeP.strokeWidth, strokeP)
        textP.textSize = r * 0.95f
        val y = h / 2 - (textP.descent() + textP.ascent()) / 2
        c.drawText(label, w / 2, y, textP)
    }
}
