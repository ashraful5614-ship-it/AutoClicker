package com.myclicker.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object UI {
    val BG = Color.parseColor("#1A1D2B")
    val NAV = Color.parseColor("#232738")
    val CARD = Color.parseColor("#2C3146")
    val CARD2 = Color.parseColor("#3A4060")
    val ACCENT = Color.parseColor("#3D7BFF")
    val GREEN = Color.parseColor("#2ECC71")
    val TEXT = Color.WHITE
    val MUTED = Color.parseColor("#9AA1B8")
    val DISABLED = Color.parseColor("#454B63")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusDp: Int, ctx: Context): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(ctx, radiusDp).toFloat()
        return g
    }

    fun text(ctx: Context, s: String, sizeSp: Float, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    /** [ label        −  value  + ] সারি; চেপে ধরলে দ্রুত বাড়ে/কমে */
    fun stepperRow(ctx: Context, f: Field): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8))

        val label = text(ctx, f.label, 14f)
        row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val value = text(ctx, f.format(f.get(ctx)), 14f, ACCENT, true)
        value.gravity = Gravity.CENTER
        value.minWidth = dp(ctx, 76)

        fun refresh() {
            value.text = f.format(f.get(ctx))
        }

        fun stepButton(sym: String, dir: Int): TextView {
            val b = text(ctx, sym, 22f, TEXT, true)
            b.gravity = Gravity.CENTER
            b.background = rounded(CARD2, 10, ctx)
            val repeat = object : Runnable {
                override fun run() {
                    f.adjust(ctx, dir)
                    refresh()
                    b.postDelayed(this, 90)
                }
            }
            b.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.isPressed = true
                        f.adjust(ctx, dir)
                        refresh()
                        v.postDelayed(repeat, 400)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        v.removeCallbacks(repeat)
                    }
                }
                true
            }
            return b
        }

        val size = dp(ctx, 38)
        row.addView(stepButton("−", -1), LinearLayout.LayoutParams(size, size))
        row.addView(value, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(stepButton("+", 1), LinearLayout.LayoutParams(size, size))
        return row
    }
}
