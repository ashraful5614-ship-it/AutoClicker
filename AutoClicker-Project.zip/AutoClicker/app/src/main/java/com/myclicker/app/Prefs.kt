package com.myclicker.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClickPoint(
    var x: Int,
    var y: Int,
    var isSwipe: Boolean = false,
    var x2: Int = 0,
    var y2: Int = 0
)

data class Script(
    val name: String,
    val multi: Boolean,
    val interval: Int,
    val loops: Int,
    val points: List<ClickPoint>
)

/** সেটিংসের ঘর: interval, loops, hold, jitter */
enum class Field(val key: String, val label: String, val def: Int, val min: Int, val max: Int) {
    INTERVAL("interval", "Interval between actions", 1000, 50, 600000),
    LOOPS("loops", "Repeat count (0 = endless)", 0, 0, 9999),
    HOLD("hold", "Tap duration", 50, 10, 2000),
    SWIPE("swipe", "Swipe duration (slower = smoother)", 300, 50, 5000),
    JITTER("jitter", "Random offset", 0, 0, 50);

    private fun stepFor(v: Int, dir: Int): Int = when (this) {
        INTERVAL -> if (dir > 0) (if (v < 1000) 50 else 100) else (if (v <= 1000) 50 else 100)
        HOLD -> 10
        SWIPE -> 50
        else -> 1
    }

    fun get(ctx: Context): Int = Prefs.sp(ctx).getInt(key, def)

    fun set(ctx: Context, v: Int) {
        Prefs.sp(ctx).edit().putInt(key, v.coerceIn(min, max)).apply()
    }

    fun adjust(ctx: Context, dir: Int) {
        val v = get(ctx)
        set(ctx, v + dir * stepFor(v, dir))
    }

    fun format(v: Int): String = when (this) {
        INTERVAL -> if (v >= 1000 && v % 100 == 0) "%.1f s".format(v / 1000.0) else "$v ms"
        LOOPS -> if (v == 0) "∞" else "$v"
        HOLD -> "$v ms"
        SWIPE -> "$v ms"
        JITTER -> "$v px"
    }
}

object Prefs {
    fun sp(ctx: Context) = ctx.getSharedPreferences("auto_clicker", Context.MODE_PRIVATE)

    fun isMulti(ctx: Context) = sp(ctx).getBoolean("multi", true)
    fun setMulti(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("multi", v).apply()

    fun pointsToJson(list: List<ClickPoint>): JSONArray {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject()
                    .put("x", p.x).put("y", p.y)
                    .put("s", p.isSwipe)
                    .put("x2", p.x2).put("y2", p.y2)
            )
        }
        return arr
    }

    fun pointsFromJson(arr: JSONArray): MutableList<ClickPoint> {
        val out = mutableListOf<ClickPoint>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                ClickPoint(
                    o.optInt("x"), o.optInt("y"),
                    o.optBoolean("s"), o.optInt("x2"), o.optInt("y2")
                )
            )
        }
        return out
    }

    fun loadCurrent(ctx: Context): MutableList<ClickPoint> {
        val s = sp(ctx).getString("current", null) ?: return mutableListOf()
        return try {
            pointsFromJson(JSONArray(s))
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveCurrent(ctx: Context, list: List<ClickPoint>) {
        sp(ctx).edit().putString("current", pointsToJson(list).toString()).apply()
    }

    fun scripts(ctx: Context): MutableList<Script> {
        val s = sp(ctx).getString("scripts", null) ?: return mutableListOf()
        val out = mutableListOf<Script>()
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Script(
                        o.optString("name", "Script"),
                        o.optBoolean("multi", true),
                        o.optInt("interval", 1000),
                        o.optInt("loops", 0),
                        pointsFromJson(o.getJSONArray("points"))
                    )
                )
            }
        } catch (e: Exception) {
            // ignore broken data
        }
        return out
    }

    fun saveScripts(ctx: Context, list: List<Script>) {
        val arr = JSONArray()
        for (sc in list) {
            arr.put(
                JSONObject()
                    .put("name", sc.name)
                    .put("multi", sc.multi)
                    .put("interval", sc.interval)
                    .put("loops", sc.loops)
                    .put("points", pointsToJson(sc.points))
            )
        }
        sp(ctx).edit().putString("scripts", arr.toString()).apply()
    }
}
