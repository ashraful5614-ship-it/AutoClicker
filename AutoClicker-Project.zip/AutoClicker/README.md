# Auto Clicker (ad-free)

## APK বানানোর সবচেয়ে সহজ উপায় (কম্পিউটার/Android Studio ছাড়া)
1. github.com এ ফ্রি অ্যাকাউন্ট খুলুন → New repository (নাম: AutoClicker, Public বা Private)।
2. "uploading an existing file" ক্লিক করে এই প্রজেক্টের সব ফাইল/ফোল্ডার (লুকানো `.github` সহ) আপলোড করুন → Commit।
3. Actions ট্যাব → "Build APK" → কাজ শেষ হলে (২-৪ মিনিট) নিচে Artifacts থেকে **AutoClicker-APK** ডাউনলোড করুন (zip খুললে app-debug.apk)।

## Android Studio দিয়ে
Android Studio-তে এই ফোল্ডার Open করুন → Build > Build APK(s)।

## চালু করা
APK ইন্সটল → অ্যাপ খুলুন → START → Accessibility-তে "Auto Clicker" ON করুন।
Android 13+ এ সুইচ ধূসর থাকলে: App info → ⋮ → Allow restricted settings।
